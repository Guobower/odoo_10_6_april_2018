{
	'name': 'Company Form', 
	'description': 'Deals with the content and changes of the company form', 
	'author': 'ECUBE', 
	'depends': ['base','web','crm'], 
	'application': True,
	'data': [
		'views/template.xml'
	 	],
}