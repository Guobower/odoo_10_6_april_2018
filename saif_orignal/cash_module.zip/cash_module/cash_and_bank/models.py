# -*- coding: utf-8 -*-
from openerp import models, fields, api
